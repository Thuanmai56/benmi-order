import { z } from 'zod';
import { seedSchema } from './tenant-seed';

export const actorSchema = z.strictObject({ id: z.string().min(1).max(200), email: z.email(),
  permissions: z.array(z.enum(['draft:edit', 'tenant:publish', 'credential:manage', 'staff:admin'])).max(4) });
export const credentialSchema = z.strictObject({
  liff_id: z.string().regex(/^\d{6,15}-[A-Za-z0-9]{4,32}$/),
  line_channel_token: z.string().min(20).max(4096),
  line_channel_secret: z.string().regex(/^[a-fA-F0-9]{32}$/),
  pos_password: z.string().min(8).max(128).refine(s => s !== '12345678'),
});
const draft = { draft_id: z.uuid() };
const revision = z.number().int().nonnegative();
export const commandSchema = z.discriminatedUnion('command', [
  z.strictObject({ command: z.literal('tenant.list'), query: z.string().max(160), cursor: z.string().max(1000).nullable() }),
  z.strictObject({ command: z.literal('tenant.available'), tenant_id: z.string().regex(/^[a-z0-9][a-z0-9_-]{1,63}$/) }),
  z.strictObject({ command: z.literal('credentials.put'), ...draft, expected_revision: revision, credentials: credentialSchema }),
  z.strictObject({ command: z.literal('credentials.get'), ...draft }),
  z.strictObject({ command: z.literal('line.check'), ...draft, credential_revision: revision }),
  z.strictObject({ command: z.literal('tenant.provision'), ...draft, draft_revision: revision, credential_revision: revision,
    data: seedSchema, idempotency_key: z.uuid(), bot_user_id: z.string().min(1).max(100),
    liff_confirmed: z.literal(true), configure_webhook: z.boolean(), previous_webhook: z.string().max(500).nullable(),
    store_status: z.enum(['open', 'paused']) }),
  z.strictObject({ command: z.literal('operation.get'), operation_id: z.uuid() }),
  z.strictObject({ command: z.literal('operation.retry'), operation_id: z.uuid() }),
]);
export const platformEnvelope = z.strictObject({ actor: actorSchema, request_id: z.uuid(), command: commandSchema });
export type PlatformCommand = z.infer<typeof commandSchema>;
export type Credentials = z.infer<typeof credentialSchema>;
export type CredentialStatus = { revision: number; liff_id: string; configured: boolean; checked_at: string | null;
  bot: { user_id: string; display_name: string } | null; webhook: { endpoint: string | null; active: boolean } | null };
export type OperationStatus = { id: string; tenant_id: string; status: 'provisioning' | 'failed' | 'succeeded';
  step: 'cache' | 'line' | 'activate' | 'complete'; error_code: string | null;
  links: { menu: string; pos: string; webhook: string; liff: string }; updated_at: string };
