import { z } from 'zod';

export const CONTRACT_VERSION = '2.0.0';
const text = (max: number) => z.string().trim().max(max);
const ref = text(100).min(1).regex(/^[a-zA-Z0-9_-]+$/);
const nullableText = (max: number) => text(max).nullable();
const time = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/);
const shift = z.strictObject({ start: time, end: time });
export const hoursSchema = z.strictObject({
  '0': z.array(shift).max(4), '1': z.array(shift).max(4), '2': z.array(shift).max(4),
  '3': z.array(shift).max(4), '4': z.array(shift).max(4), '5': z.array(shift).max(4), '6': z.array(shift).max(4),
});
export type Hours = z.infer<typeof hoursSchema>;
export const tenantSchema = z.strictObject({
  id: text(64), brand_name: text(160), brand_color: text(7), store_address: text(500),
  locale: z.enum(['vi', 'zh-TW']), operating_hours: hoursSchema,
  delivery_policy: text(2000), allow_scheduled_pickup: z.boolean(), allow_dine_in: z.boolean(),
});
const itemSchema = z.strictObject({
  ref, name: text(160), price: z.number().finite().min(0).max(1_000_000).nullable(),
  description: nullableText(2000), badge_text: nullableText(100),
  is_recommended: z.boolean(), sort_order: z.number().int().min(0).max(10000),
});
const baseCategory = {
  ref, slug: text(80), name: text(160), sort_order: z.number().int().min(0).max(10000),
  items: z.array(itemSchema).max(500),
};
export const categorySchema = z.discriminatedUnion('category_type', [
  z.strictObject({ ...baseCategory, category_type: z.literal('catalog'),
    allow_customization: z.boolean(), applied_modifiers: z.array(ref).max(100).nullable() }),
  z.strictObject({ ...baseCategory, category_type: z.literal('modifier'),
    selection_type: z.enum(['single', 'multiple', 'combo_drink']), is_required: z.boolean(),
    min_selection: z.number().int().min(0).max(500), max_selection: z.number().int().min(1).max(500) }),
]);
export const issueCodes = ['required', 'tenant_id', 'color', 'duplicate', 'price', 'modifier_assignment',
  'modifier_reference', 'selection', 'hours', 'too_many_items', 'no_catalog', 'import_hours', 'review_source'] as const;
export type IssueCode = typeof issueCodes[number];
export const warningSchema = z.strictObject({
  path: text(200), code: z.enum(issueCodes), source: nullableText(500), resolved: z.boolean(),
});
export const seedSchema = z.strictObject({
  schema_version: z.literal(2), tenant: tenantSchema, categories: z.array(categorySchema).max(100),
  warnings: z.array(warningSchema).max(1000),
});
export type TenantSeed = z.infer<typeof seedSchema>;
export type Category = z.infer<typeof categorySchema>;
export type MenuItem = z.infer<typeof itemSchema>;
export type ValidationIssue = { path: string; code: IssueCode };

export function emptyHours(): Hours {
  return { '0': [], '1': [], '2': [], '3': [], '4': [], '5': [], '6': [] };
}
export function emptySeed(): TenantSeed {
  return { schema_version: 2, tenant: { id: '', brand_name: '', brand_color: '#147d64', store_address: '',
    locale: 'vi', operating_hours: emptyHours(), delivery_policy: '', allow_scheduled_pickup: true,
    allow_dine_in: false }, categories: [], warnings: [] };
}
export function newItem(): MenuItem {
  return { ref: crypto.randomUUID(), name: '', price: null, description: null, badge_text: null,
    is_recommended: false, sort_order: 0 };
}
export function newCategory(type: Category['category_type']): Category {
  const base = { ref: crypto.randomUUID(), name: '', slug: '', sort_order: 0, items: [newItem()] };
  return type === 'catalog' ? { ...base, category_type: type, allow_customization: false, applied_modifiers: [] }
    : { ...base, category_type: type, selection_type: 'single', is_required: false, min_selection: 0, max_selection: 1 };
}

/** Drafts allow incomplete values. Publication uses this additional semantic gate. */
export function validateForPublish(seed: TenantSeed): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const add = (path: string, code: IssueCode) => issues.push({ path, code });
  if (!/^[a-z0-9][a-z0-9_-]{1,63}$/.test(seed.tenant.id)) add('tenant.id', 'tenant_id');
  if (!seed.tenant.brand_name.trim()) add('tenant.brand_name', 'required');
  if (!seed.tenant.store_address.trim()) add('tenant.store_address', 'required');
  if (!/^#[a-fA-F0-9]{6}$/.test(seed.tenant.brand_color)) add('tenant.brand_color', 'color');
  if (!Object.values(seed.tenant.operating_hours).some(shifts => shifts.length)) add('tenant.operating_hours', 'hours');
  for (const [day, shifts] of Object.entries(seed.tenant.operating_hours)) {
    const ordered = [...shifts].sort((a, b) => a.start.localeCompare(b.start));
    if (ordered.some((s, i) => s.end <= s.start || (i > 0 && s.start < ordered[i - 1].end)))
      add(`tenant.operating_hours.${day}`, 'hours');
  }
  const refs = new Set<string>();
  const slugs = new Set<string>();
  const modifierRefs = new Set(seed.categories.filter(c => c.category_type === 'modifier').map(c => c.ref));
  if (!seed.categories.some(c => c.category_type === 'catalog' && c.items.length)) add('categories', 'no_catalog');
  if (seed.categories.reduce((n, c) => n + c.items.length, 0) > 500) add('categories', 'too_many_items');
  seed.categories.forEach((cat, index) => {
    const p = `categories[${index}]`;
    if (refs.has(cat.ref)) add(`${p}.ref`, 'duplicate');
    refs.add(cat.ref);
    if (slugs.has(cat.slug)) add(`${p}.slug`, 'duplicate');
    slugs.add(cat.slug);
    if (!/^[a-z0-9][a-z0-9_-]*$/.test(cat.slug)) add(`${p}.slug`, 'required');
    if (!cat.name.trim()) add(`${p}.name`, 'required');
    if (!cat.items.length) add(`${p}.items`, 'required');
    if (cat.category_type === 'catalog') {
      if (cat.applied_modifiers === null || (cat.allow_customization && !cat.applied_modifiers.length))
        add(`${p}.applied_modifiers`, 'modifier_assignment');
      if ((!cat.allow_customization && (cat.applied_modifiers?.length ?? 0) > 0)
        || cat.applied_modifiers?.some(r => !modifierRefs.has(r))
        || new Set(cat.applied_modifiers).size !== (cat.applied_modifiers?.length ?? 0))
        add(`${p}.applied_modifiers`, 'modifier_reference');
    } else if (cat.min_selection > cat.max_selection || (cat.selection_type === 'single' && cat.max_selection !== 1)
      || cat.is_required !== (cat.min_selection > 0) || cat.min_selection > cat.items.length) {
      add(`${p}.min_selection`, 'selection');
    }
    cat.items.forEach((item, i) => {
      if (refs.has(item.ref)) add(`${p}.items[${i}].ref`, 'duplicate');
      refs.add(item.ref);
      if (!item.name.trim()) add(`${p}.items[${i}].name`, 'required');
      if (item.price === null) add(`${p}.items[${i}].price`, 'price');
    });
  });
  seed.warnings.filter(w => !w.resolved).forEach(w => add(w.path, w.code));
  return issues;
}

const legacyItem = z.strictObject({
  id: ref, name: text(160), price: z.number().finite().min(0).nullable(),
  description: nullableText(2000).optional(), badge_text: nullableText(100).optional(),
  is_recommended: z.boolean().optional(), sort_order: z.number().int().min(0).optional(),
});
const legacySchema = z.strictObject({
  tenant: z.strictObject({ id: text(64), brand_name: text(160), brand_color: text(7), store_address: text(500),
    operating_hours: z.union([text(2000), hoursSchema]), allow_scheduled_pickup: z.boolean(),
    locale: z.enum(['vi', 'zh-TW']), delivery_policy: text(2000), allow_dine_in: z.boolean().optional() }),
  categories: z.array(z.strictObject({
    id: ref, slug: text(80), name: text(160), category_type: z.enum(['catalog', 'modifier']),
    selection_type: z.enum(['single', 'multiple', 'combo_drink']), is_required: z.boolean(),
    min_selection: z.number().int().min(0), max_selection: z.number().int().min(1),
    sort_order: z.number().int().min(0), items: z.array(legacyItem).max(500),
    allow_customization: z.boolean().optional(), applied_modifiers: z.array(ref).optional(),
  })).max(100),
});

export function importSeed(input: string): TenantSeed {
  if (new TextEncoder().encode(input).byteLength > 1_000_000) throw new Error('IMPORT_TOO_LARGE');
  const raw: unknown = JSON.parse(input.trim().replace(/^```(?:json)?\s*\n([\s\S]*?)\n```$/, '$1'));
  if (typeof raw === 'object' && raw !== null && 'schema_version' in raw) return seedSchema.parse(raw);
  const legacy = legacySchema.parse(raw);
  const warnings: TenantSeed['warnings'] = [];
  let hours = emptyHours();
  if (typeof legacy.tenant.operating_hours === 'string') {
    const match = /^([0-2]\d:[0-5]\d)-([0-2]\d:[0-5]\d)$/.exec(legacy.tenant.operating_hours.trim());
    if (match && shift.safeParse({ start: match[1], end: match[2] }).success) {
      for (const day of Object.keys(hours) as Array<keyof Hours>) hours[day] = [{ start: match[1], end: match[2] }];
    }
    warnings.push({ path: 'tenant.operating_hours', code: 'import_hours', source: legacy.tenant.operating_hours, resolved: false });
  } else hours = legacy.tenant.operating_hours;
  const categories: Category[] = legacy.categories.map(c => {
    const base = { ref: c.id, slug: c.slug, name: c.name, sort_order: c.sort_order,
      items: c.items.map((item, i) => ({ ref: item.id, name: item.name, price: item.price,
        description: item.description ?? null, badge_text: item.badge_text ?? null,
        is_recommended: item.is_recommended ?? false, sort_order: item.sort_order ?? i })) };
    if (c.category_type === 'modifier') return { ...base, category_type: 'modifier',
      selection_type: c.selection_type, is_required: c.is_required, min_selection: c.min_selection, max_selection: c.max_selection };
    return { ...base, category_type: 'catalog', allow_customization: c.allow_customization ?? false,
      applied_modifiers: c.applied_modifiers ?? (c.allow_customization === false ? [] : null) };
  });
  return seedSchema.parse({ schema_version: 2, tenant: { ...legacy.tenant, operating_hours: hours,
    allow_dine_in: legacy.tenant.allow_dine_in ?? false }, categories, warnings });
}
