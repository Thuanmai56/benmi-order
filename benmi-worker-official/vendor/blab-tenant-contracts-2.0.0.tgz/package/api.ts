import type { TenantSeed } from './tenant-seed';
export type Permission = 'draft:edit' | 'tenant:publish' | 'credential:manage' | 'staff:admin';
export type Actor = { id: string; email: string; permissions: Permission[] };
export type Session = { actor: Actor; environment: string };
export type DraftStatus = 'draft' | 'review' | 'publishing' | 'published';
export type Draft = { id: string; revision: number; status: DraftStatus; data: TenantSeed;
  owner_id: string; created_at: string; updated_at: string; operation_id: string | null };
export type DraftSummary = Omit<Draft, 'data'> & { tenant_id: string; brand_name: string; item_count: number };
